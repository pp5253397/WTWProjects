
from django.urls import path
# from .views import OrganisationView,LoginView,index,CustomerView,CustomerFormView,delete,edit,update,logout,invoicePage,InvoiceView
from .views import OrganisationView,LoginView,index,CustomerView,CustomerDelete,CustomerUpdate,CustomerFormView,InvoiceView,InvoicePage,InvoiceForm,InvoiceDelete,InvoiceUpdate,ProductView,ProductForm,ProductDelete,ProductUpdate,DetailPage
from . import views


urlpatterns = [
    path('signup/',OrganisationView,name = 'signup'),
    path('login/',LoginView, name='login'),
    path('index/',index, name = 'index'),
    path('customer/',CustomerView,name = 'customer'),
    path('customerform/',CustomerFormView,name = 'customerform'),
    path('customerDelete/<int:cust_del>/',CustomerDelete,name='CustDel'),
    path('customerUpdate/<int:cust_up>/',CustomerUpdate,name='CustUp'),
    path('invoiceview/',InvoiceView,name = 'invoiceview'),
    path('invoicepage/<int:id>/',InvoicePage,name='invopage'),
    path('invoiceform/',InvoiceForm,name='invoiceform'),
    path('invoiceDelete/<int:invo_del>/',InvoiceDelete,name='InvoDel'),
    path('invoiceUpdate/<int:invo_up>/',InvoiceUpdate,name='InvoUp'),
    path('productview/',ProductView,name = 'productview'),
    path('productform/',ProductForm,name='productform'),
    path('productDelete/<int:prod_del>/',ProductDelete,name='ProdDel'),
    path('productUpdate/<int:prod_up>/',ProductUpdate,name='ProdUp'),
    path('detailpage/<int:id>',DetailPage,name='detailpage'),
]