from django.apps import AppConfig


class OrganisationConfig(AppConfig):
    name = 'organisation'
