from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from .models import OrganisationDetails,CustomerDetails,Invoice_Details,Product
from .forms import OrganisationForm,CustomerForm,Invoice_Details_Form,Product_Form
from django.urls import reverse_lazy
from django.http import HttpResponse

from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate


def OrganisationView(request):
    forms = OrganisationForm(request.POST or None)
    if request.POST:
        if forms.is_valid():
            forms.save()
            # request.session['user'] = request.POST['user_id']
            return HttpResponseRedirect('/org/index')
        else:
            print('not valid')
    else:
        print('not post')
    return render(request,'signup.html',{'org':forms})

def LoginView(request):
    if request.method == "POST":
        try:
            m = OrganisationDetails.objects.get(user_id = request.POST['username'])
            if m.password_2 == request.POST['password']:
                print(m.user_id)
                # request.session['user'] = m.user_id
                return HttpResponseRedirect('/org/index')
            else:
                return HttpResponse("<h2><a href=''>You have entered wrong password</a></h2>")
        except:
            return HttpResponse("<h2><a href=''>no username found.</a></h2>")
    return render(request,'registration/login.html')

def index(request):
    cust_count = CustomerDetails.objects.count()
    invoice_count = Invoice_Details.objects.count()
    return render(request,'index.html',{'cust_count':cust_count,'invo_count':invoice_count})

def CustomerView(request):
    # if request.session.keys():
    model = CustomerDetails.objects.all()
    return render(request,'customer.html',{'customerdata':model})
    # else:
    #     return redirect('login')

def CustomerFormView(request):
    # if request.session.keys():
    form = CustomerForm(request.POST)
    if form.is_valid():
        form.save()
        return redirect('/org/customer')
    return render(request,'customerform.html',{'data':form})
    # else:
    #     return redirect('login')

def CustomerDelete(request,cust_del):
    data = CustomerDetails.objects.get(id=cust_del)
    data.delete()
    return redirect('customer')
    
def CustomerUpdate(request,cust_up):    
    profile = CustomerDetails.objects.get(id=cust_up)
    form = CustomerForm(instance = profile,data=request.POST or None)
    if form.is_valid():
        print("yes")
        form.save()
        return redirect('customer')
    return render(request,'customerform.html',{'data':form})
    
def InvoiceView(request):
    cust_data = CustomerDetails.objects.all()
    cust = []
    inv = []
    for i in cust_data:
        print(i)
        cust.append(i)
        in_data = Invoice_Details.objects.filter(Cust_name=i).count()
        print(in_data)
        inv.append(in_data)
    
    data = zip(cust,inv)
    return render(request,'temp_invoice.html',{'data':data})

def InvoicePage(request,id):
    cust_data = CustomerDetails.objects.get(id=id)
    in_data = Invoice_Details.objects.filter(Cust_name=cust_data)
    invo = []
    pro = []
    pro_tot = []
    
    for i in in_data:
        print(i)
        invo.append(i)
        
        pro_count = Product.objects.filter(Invoice=i).count()
        print(pro_count)
        pro.append(pro_count)
        t = 0
        pro_data = Product.objects.filter(Invoice=i)
        for i in pro_data:
            t += int(i.Total)
        pro_tot.append(t)
        
    data = zip(invo,pro,pro_tot)
    return render(request,'invoice_list.html',{'cust':cust_data,'invo':data})
    
def DetailPage(request,id):
    invo = Invoice_Details.objects.get(id=id)
    prod = Product.objects.filter(Invoice=invo)
    cust_data = CustomerDetails.objects.get(cust_name=invo.Cust_name)
    tot = 0
    for i in prod:
        tot += int(i.Total)
    return render(request,'DetailPage.html',{'cust':cust_data,'invo':invo,'prod':prod,'tot':tot})

def InvoiceForm(request):
    form = Invoice_Details_Form(request.POST)
    print("sdfdsa")
    if form.is_valid():
        
        form.save()
        return redirect('invoiceview')
    return render(request,'invoiceform.html',{'data':form})

def InvoiceDelete(request,invo_del):
    data = Invoice_Details.objects.get(id=invo_del)
    data.delete()
    return redirect('invoiceview')
    
def InvoiceUpdate(request,invo_up):
    profile = Invoice_Details.objects.get(id=invo_up)
    form = Invoice_Details_Form(instance = profile,data=request.POST or None)
    if form.is_valid():
        print("yes")
        form.save()
        return redirect('invoiceview')
    return render(request,'invoiceform.html',{'data':form})

def ProductView(request):
    pro_data = Product.objects.all()
    return render(request,'temp_product.html',{'prod_data':pro_data})

def ProductForm(request):
    form = Product_Form(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('/org/invoiceview/')
    return render(request,'productform.html',{'data':form})

def ProductDelete(request,prod_del):
    data = Product.objects.get(id=prod_del)
    data.delete()
    return redirect('/org/invoiceview/')
    
def ProductUpdate(request,prod_up):
    profile = Product.objects.get(id=prod_up)
    form = Product_Form(instance = profile,data=request.POST or None)
    if form.is_valid():
        print("yes")
        form.save()
        return redirect('/org/invoiceview/')
    return render(request,'productform.html',{'data':form})

def logout(request):
    if request.session.keys():
        request.session.flush()
        return redirect('/org/login/')
    else:
        return redirect('/org/login/')



